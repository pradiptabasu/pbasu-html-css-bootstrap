<p align="center">
  <a href="https://luosijie.github.io/vue-resume/#/">
    <img src="https://github.com/luosijie/Front-end-Blog/blob/master/img/logo_vue_resume.jpg?raw=true">
  </a>
</p>

### Usage

![usage](https://github.com/luosijie/Front-end-Blog/blob/master/img/vue_resume_usage.PNG?raw=true)

### Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
