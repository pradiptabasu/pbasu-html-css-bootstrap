// English
const lang = {
    contact: 'Contact',
    born: 'Born',
    bornIn: 'in',
    experience: 'Experience',
    education: 'Education',
    skills: 'Skills',
    projects: 'Projects',
    contributions: 'Contributions',
    about: 'About me'
};
export default lang;
