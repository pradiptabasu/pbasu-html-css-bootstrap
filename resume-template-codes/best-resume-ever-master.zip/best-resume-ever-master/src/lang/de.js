// Dutch
const lang = {
    contact: 'Kontakt',
    born: 'Geboren',
    bornIn: 'in',
    experience: 'Berufserfahrung',
    education: 'Schulbildung',
    skills: 'Qualifikationen',
    projects: 'Projekte',
    contributions: 'Mitarbeit',
    about: 'Über mich'
};
export default lang;
