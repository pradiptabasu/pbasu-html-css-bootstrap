const lang = {
    contact: 'Επικοινωνία',
    experience: 'Επαγγελματική εμπειρία',
    education: 'Εκπαίδευση',
    skills: 'Δεξιότητες',
    about: 'Σχετικά με εμένα'
};
export default lang;
