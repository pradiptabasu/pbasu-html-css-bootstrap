const lang = {
    contact: 'Kontakt',
    experience: 'Arbetslivserfarenhet',
    education: 'Utbildning',
    skills: 'Kunskaper',
    about: 'Om mig'
};
export default lang;
