// If you create a new resume, import it here:
import './material-dark.vue';
import './left-right.vue';
import './oblique.vue';
import './side-bar.vue';
import './purple.vue';
import './side-bar-rtl.vue';
import './left-right-rtl.vue';
import './creative.vue';
import './cool.vue';
