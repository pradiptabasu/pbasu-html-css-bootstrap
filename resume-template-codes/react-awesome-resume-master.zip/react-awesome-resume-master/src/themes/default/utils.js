export const notEmpty = (array) => {
  return array.length > 0;
};
