import Resume from "./Resume";

export default Resume;