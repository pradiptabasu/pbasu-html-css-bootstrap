export const careerProfile = {
  sectionTitle: 'Career Profile',
  icon: null,
  description: '<p>I\'m coding something since I was 14. In the beginning I was creating game servers for popular games, after that I started with php and created some basic apps for small-sized companies. Then I decided to train myself. And now, I have successfully finished a good many projects you can see the project details <a href="#projects">below.</a> So, may be we can work together!</p>'
};

export default careerProfile;
