export const tags = {
  sectionTitle: '',
  icon: null,
  list: [
    'Javascript',
    'ReactJS',
    'ReactNative',
    'Redux',
    'Webpack',
    'Npm/Yarn',
    'Git',
    'C#',
    'ASP.NETMVC',
    'PHP',
    'SOLID PRINCIPLES',
    'XAMARIN',
    'LINQ',
    'N-TIER ARCHITECTURE',
    'SOA ARCHITECTURE']
};

export default tags;
