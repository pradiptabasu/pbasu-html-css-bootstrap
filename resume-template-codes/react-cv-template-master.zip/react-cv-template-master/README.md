A React CV Template APP with six different color schemes, just clone the repository and edit js files under src/data folder.


After cloning repository, just

- npm install / yarn install
- npm start / yarn start
- npm build / yarn build

Sample Page
[http://sbaydin.com](http://sbaydin.com/)

##Credits
- [React](https://facebook.github.io/react/)
- [Theme -  Xiaoying Riley - Orbit Theme](https://github.com/xriley/)
- [Bootstrap](http://getbootstrap.com/)
- [FontAwesome](http://fortawesome.github.io/Font-Awesome/)
- [jQuery](http://jquery.com/)

## Support on Beerpay
Hey dude! Help me out for a couple of :beers:!

[![Beerpay](https://beerpay.io/sbayd/react-cv-template/badge.svg?style=beer-square)](https://beerpay.io/sbayd/react-cv-template)  [![Beerpay](https://beerpay.io/sbayd/react-cv-template/make-wish.svg?style=flat-square)](https://beerpay.io/sbayd/react-cv-template?focus=wish)