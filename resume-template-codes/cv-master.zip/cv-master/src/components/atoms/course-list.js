import styled from 'styled-components';

const CoursesList = styled.ul`
  display: flex;
  flex-direction: column;
  padding: 0.4rem 0;
`;

export default CoursesList;
